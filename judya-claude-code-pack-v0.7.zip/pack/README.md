# JudYa Claude-Code pack v0.7
Start with `HANDOFF.md`. To build: paste `docs/prompts/judya-v07-build.md` into Claude Code in the MedMate repo and attach/copy this folder into it (`docs/`, `reference/`, `prototype/`). Quick check: `node reference/calc.test.mjs` → "18 tests passed".
